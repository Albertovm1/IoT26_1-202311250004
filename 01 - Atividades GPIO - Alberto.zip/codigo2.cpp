#include <Arduino.h>
#include <cstdio>
#include "driver/ledc.h"
#include "driver/gpio.h"

// Definições dos pinos
#define LED_0 4
#define LED_1 5
#define LED_2 6
#define LED_3 7
#define BUZZER 1
#define BOTAO_A 2
#define BOTAO_B 42

#define LEDC_RES      LEDC_TIMER_10_BIT
#define LEDC_MAX_DUTY 1023

static volatile bool flag_led_max = false;   
static volatile bool flag_buzzer_15s = false; 

static void IRAM_ATTR isr_botoes(void* arg) {
    uint32_t pino = (uint32_t)arg;
    if (pino == BOTAO_A) flag_led_max = !flag_led_max;
    if (pino == BOTAO_B) flag_buzzer_15s = true;
}

void setup_codigo2() {
    // Configuração dos Timers
    ledc_timer_config_t t_leds = { .speed_mode = LEDC_LOW_SPEED_MODE, .duty_resolution = LEDC_RES, .timer_num = LEDC_TIMER_0, .freq_hz = 1000, .clk_cfg = LEDC_AUTO_CLK };
    ledc_timer_config(&t_leds);

    ledc_timer_config_t t_buzz = { .speed_mode = LEDC_LOW_SPEED_MODE, .duty_resolution = LEDC_RES, .timer_num = LEDC_TIMER_1, .freq_hz = 500, .clk_cfg = LEDC_AUTO_CLK };
    ledc_timer_config(&t_buzz);

    int pins[] = {LED_0, LED_1, LED_2, LED_3};
    for (int i = 0; i < 4; i++) {
        ledc_channel_config_t c = { .gpio_num = (gpio_num_t)pins[i], .speed_mode = LEDC_LOW_SPEED_MODE, .channel = (ledc_channel_t)i, .intr_type = LEDC_INTR_DISABLE, .timer_sel = LEDC_TIMER_0, .duty = 0, .hpoint = 0 };
        ledc_channel_config(&c);
    }
    ledc_channel_config_t cb = { .gpio_num = (gpio_num_t)BUZZER, .speed_mode = LEDC_LOW_SPEED_MODE, .channel = LEDC_CHANNEL_4, .intr_type = LEDC_INTR_DISABLE, .timer_sel = LEDC_TIMER_1, .duty = 0, .hpoint = 0 };
    ledc_channel_config(&cb);

    gpio_config_t btn_cfg = { .pin_bit_mask = (1ULL << BOTAO_A) | (1ULL << BOTAO_B), .mode = GPIO_MODE_INPUT, .pull_up_en = GPIO_PULLUP_ENABLE, .intr_type = GPIO_INTR_NEGEDGE };
    gpio_config(&btn_cfg);
    
    gpio_install_isr_service(0);
    gpio_isr_handler_add((gpio_num_t)BOTAO_A, isr_botoes, (void*)BOTAO_A);
    gpio_isr_handler_add((gpio_num_t)BOTAO_B, isr_botoes, (void*)BOTAO_B);
}

void loop_codigo2() {
    static int p = 0, dir = 1;
    static uint32_t tempo_buzzer_fixo = 0;

    if (flag_buzzer_15s) {
        flag_buzzer_15s = false;
        tempo_buzzer_fixo = 50; 
        ledc_set_freq(LEDC_LOW_SPEED_MODE, LEDC_TIMER_1, 1000); 
        ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4, 512); 
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4);
    }

    if (tempo_buzzer_fixo > 0) {
        tempo_buzzer_fixo--;
    } else {
        int freq = 500 + (15 * p);
        int brilho = (LEDC_MAX_DUTY * p) / 100;
        ledc_set_freq(LEDC_LOW_SPEED_MODE, LEDC_TIMER_1, freq);
        uint32_t d = flag_led_max ? LEDC_MAX_DUTY : brilho;
        for (int i = 0; i < 4; i++) {
            ledc_set_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)i, d);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)i);
        }
        ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4, 80); 
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_4);
        p += dir;
        if (p >= 100 || p <= 0) dir *= -1;
    }
    vTaskDelay(pdMS_TO_TICKS(30));
}