#include <Arduino.h>
#include <cstdio>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

// Definições dos pinos
#define LED_0 4
#define LED_1 5
#define LED_2 6
#define LED_3 7

void setup_codigo1() {
    gpio_reset_pin((gpio_num_t)LED_0); gpio_set_direction((gpio_num_t)LED_0, GPIO_MODE_OUTPUT);
    gpio_reset_pin((gpio_num_t)LED_1); gpio_set_direction((gpio_num_t)LED_1, GPIO_MODE_OUTPUT);
    gpio_reset_pin((gpio_num_t)LED_2); gpio_set_direction((gpio_num_t)LED_2, GPIO_MODE_OUTPUT);
    gpio_reset_pin((gpio_num_t)LED_3); gpio_set_direction((gpio_num_t)LED_3, GPIO_MODE_OUTPUT);
}

void loop_codigo1() {
    // --- FASE 1: Contador Binário
    printf("Fase 1 - Contador Binário\n");
    for (int contador = 0; contador <= 15; contador++) {
        if (Serial.available()) return;
        gpio_set_level((gpio_num_t)LED_0, (contador >> 0) & 1);
        gpio_set_level((gpio_num_t)LED_1, (contador >> 1) & 1);
        gpio_set_level((gpio_num_t)LED_2, (contador >> 2) & 1);
        gpio_set_level((gpio_num_t)LED_3, (contador >> 3) & 1);
        
        vTaskDelay(pdMS_TO_TICKS(500));
    }

    // --- FASE 2: Sequência de Varredura
    printf("Fase 2 - Sequência de Varredura\n");
    
    // Ida: LED 0 até LED 3
    for (int p = 0; p < 4; p++) {
        if (Serial.available()) return;
        gpio_set_level((gpio_num_t)LED_0, (p == 0));
        gpio_set_level((gpio_num_t)LED_1, (p == 1));
        gpio_set_level((gpio_num_t)LED_2, (p == 2));
        gpio_set_level((gpio_num_t)LED_3, (p == 3));
        vTaskDelay(pdMS_TO_TICKS(500));
    }    
    for (int p = 2; p >= 1; p--) {
        if (Serial.available()) return;
        gpio_set_level((gpio_num_t)LED_0, (p == 0));
        gpio_set_level((gpio_num_t)LED_1, (p == 1));
        gpio_set_level((gpio_num_t)LED_2, (p == 2));
        gpio_set_level((gpio_num_t)LED_3, (p == 3));
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}