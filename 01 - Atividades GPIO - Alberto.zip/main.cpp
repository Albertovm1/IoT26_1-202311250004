#include <Arduino.h>
#include "driver/ledc.h"

void setup_codigo1();
void loop_codigo1();
void setup_codigo2();
void loop_codigo2();

int escolha = 0;

void reset_hardware() {
    // Para todos os canais de PWM (0 a 7) e desliga o Buzzer
    for (int i = 0; i < 8; i++) {
        ledc_stop(LEDC_LOW_SPEED_MODE, (ledc_channel_t)i, 0);
    }
    // Garante que os LEDs comecem apagados
    digitalWrite(4, LOW); digitalWrite(5, LOW);
    digitalWrite(6, LOW); digitalWrite(7, LOW);
    Serial.println("Hardware Resetado.");
}

void setup() {
    Serial.begin(115200);
    Serial.println("\n--- Seja bem-vindo, professor Alexandre ---");
    Serial.println("Digite '1' para o Código 1 (Binário/Varredura)");
    Serial.println("Digite '2' para o Código 2 (Fading/Buzzer)");
    Serial.println("OBS: você pode trocar o código a qualquer momento!");
}

void loop() {
    if (Serial.available()) {
        char c = Serial.read();
        
        if (c == '1') {
            reset_hardware(); // reset
            setup_codigo1();
            escolha = 1;
            Serial.println("\n>> Rodando Código 1...");
        } 
        else if (c == '2') {
            reset_hardware(); // reset
            setup_codigo2();
            escolha = 2;
            Serial.println("\n>> Rodando Código 2...");
        }
    }
    if (escolha == 1) loop_codigo1();
    if (escolha == 2) loop_codigo2();

    yield();
}